/**
 * An abstract class to represent an Expression
 */
public abstract class Expression extends Statement {
   
	@Override
	public Object eval(Environment env) {
		return null;
	}

}
