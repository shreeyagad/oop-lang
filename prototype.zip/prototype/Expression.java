/**
 * An abstract class to represent an expression
 * 
 */

public abstract class Expression {
   
	public Object eval() {
		return null;
	}

}
