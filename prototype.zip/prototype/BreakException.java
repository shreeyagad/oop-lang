/**
 * Represents a Break Exception, that will break the while loop
 */
public class BreakException extends RuntimeException {
    
}