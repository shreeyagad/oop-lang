/**
 * An abstract class to represent a Statement
 */
public abstract class Statement {

	public Object eval(Environment env) {
		return null;
	}
	
}
